package com.psnet.temporalprobe

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.os.PowerManager
import android.content.Context
import android.view.WindowManager

class MainActivity : AppCompatActivity() {

    private lateinit var probe: HexagramProbe
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Keep the screen on at all times while the app is open
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Acquire a wake lock so the CPU never sleeps
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "TemporalProbe::WakeLock"
        )
        wakeLock?.acquire()

        // Start the probe
        probe = HexagramProbe(applicationContext, samplingIntervalSeconds = 1L)
        probe.start()
    }

    override fun onDestroy() {
        super.onDestroy()

        // Stop the probe
        probe.stop()

        // Release the wake lock
        wakeLock?.release()
        wakeLock = null
    }
}
