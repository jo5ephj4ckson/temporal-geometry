package com.psnet.temporalprobe

import android.content.Context
import android.os.Environment
import android.os.Handler
import android.os.Looper
import java.io.File
import java.io.FileWriter
import java.io.IOException
import kotlin.random.Random

class HexagramProbe(
    private val context: Context,
    private val samplingIntervalSeconds: Long
) {

    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var writer: FileWriter? = null

    private val probeRunnable = object : Runnable {
        override fun run() {
            if (!running) return

            try {
                val hexagram = generateHexagram()
                writeHexagram(hexagram)
            } catch (_: Exception) {
                // swallow exceptions so the app never crashes
            }

            handler.postDelayed(this, samplingIntervalSeconds * 1000L)
        }
    }

    fun start() {
        if (running) return
        running = true

        try {
            val downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val file = File(downloads, "hexagrams.csv")
            val exists = file.exists()

            writer = FileWriter(file, true)

            if (!exists) {
                writer?.write("timestamp,line1,line2,line3,line4,line5,line6\n")
                writer?.flush()
            }

        } catch (_: IOException) {
            running = false
            writer = null
            return
        }

        handler.post(probeRunnable)
    }

    fun stop() {
        running = false
        handler.removeCallbacks(probeRunnable)

        try {
            writer?.flush()
            writer?.close()
        } catch (_: IOException) {}

        writer = null
    }

    private fun generateHexagram(): Hexagram {
        val lines = IntArray(6) { Random.nextInt(0, 2) }
        val timestamp = System.currentTimeMillis()
        return Hexagram(timestamp, lines)
    }

    private fun writeHexagram(hexagram: Hexagram) {
        val w = writer ?: return

        val line = buildString {
            append(hexagram.timestamp)
            append(',')
            append(hexagram.lines[0])
            append(',')
            append(hexagram.lines[1])
            append(',')
            append(hexagram.lines[2])
            append(',')
            append(hexagram.lines[3])
            append(',')
            append(hexagram.lines[4])
            append(',')
            append(hexagram.lines[5])
            append('\n')
        }

        w.write(line)
        w.flush()
    }

    data class Hexagram(
        val timestamp: Long,
        val lines: IntArray
    )
}
